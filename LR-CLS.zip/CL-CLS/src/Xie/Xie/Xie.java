package Xie.Xie;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class Xie {

    private static Pairing pairing;
    private static Element g, omega, Ppub, t;

    // Setup Function
    public static void setup() {
        pairing = PairingFactory.getPairing("a.properties");
        g = pairing.getG1().newRandomElement().getImmutable();
        t = pairing.getZr().newRandomElement().getImmutable();
        omega = g.powZn(t).getImmutable();

        System.out.println("Setup complete. Public parameters generated.");
    }

    // Generate Partial Private Key
    public static Map<String, Element> generatePartialPrivateKey(String IDv) {
        Map<String, Element> partialKeys = new HashMap<>();

        Element Hv = hashToZr(IDv + omega.toString());
        Element mu_v = t.add(Hv).getImmutable();

        partialKeys.put("mu_v", mu_v);
        partialKeys.put("Hv", Hv);

        System.out.println("Partial private key generated for IDv: " + IDv);
        return partialKeys;
    }

    // Generate Public/Private Key Pair
    public static Map<String, Element> generateKeys(Map<String, Element> partialKey) {
        Map<String, Element> keys = new HashMap<>();

        Element mu_v = partialKey.get("mu_v");
        Element Hv = partialKey.get("Hv");

        Element b_v = pairing.getZr().newRandomElement().getImmutable();
        Element Sk_v = mu_v.add(b_v).getImmutable();

        Element X_v = g.powZn(mu_v).getImmutable();
        Element Y_v = g.powZn(b_v).getImmutable();

        keys.put("Sk_v", Sk_v);
        keys.put("X_v", X_v);
        keys.put("Y_v", Y_v);

        System.out.println("Public/Private keys generated.");
        return keys;
    }

    // Offline Signcryption
    public static Map<String, Element> offlineSigncrypt(Element Pk_R, Element Sk_v) {
        Map<String, Element> offlineCiphertext = new HashMap<>();

        Element xi_v = pairing.getZr().newRandomElement().getImmutable();
        Element W_v = g.powZn(xi_v).getImmutable();
        Element F_v = Pk_R.powZn(xi_v).getImmutable();

        offlineCiphertext.put("xi_v", xi_v);
        offlineCiphertext.put("W_v", W_v);
        offlineCiphertext.put("F_v", F_v);

        System.out.println("Offline signcryption complete.");
        return offlineCiphertext;
    }

    // Online Signcryption
    public static Map<String, Object> onlineSigncrypt(String m_v, Map<String, Element> offlineCiphertext, Element Sk_v, Element Pk_v, Element Hv) {
        Map<String, Object> ciphertext = new HashMap<>();

        Element W_v = offlineCiphertext.get("W_v");
        Element xi_v = offlineCiphertext.get("xi_v");

        Element h_v = hashToZr(W_v.toString());
        String lambda_v = xorStrings(m_v, hashToString(h_v));

        Element j_v = hashToZr(m_v + Hv.toString() + Pk_v.toString() + W_v.toString());
        Element beta_v = j_v.invert().mul(Sk_v.add(xi_v)).getImmutable();

        ciphertext.put("lambda_v", lambda_v);
        ciphertext.put("beta_v", beta_v);
        ciphertext.put("F_v", offlineCiphertext.get("F_v"));

        Integer totalBits = 0;
        totalBits+=lambda_v.getBytes().length;
        totalBits+= beta_v.toBytes().length;
        totalBits+=offlineCiphertext.get("F_v").toBytes().length;
        System.out.println("密文长度为"+totalBits/8+"B");

        System.out.println("Online signcryption complete.");
        return ciphertext;
    }

    // Unsigncryption
    public static String unsigncrypt(Map<String, Object> ciphertext, Element Sk_R, Element Pk_v, Element Hv) {
        String lambda_v = (String) ciphertext.get("lambda_v");
        Element beta_v = (Element) ciphertext.get("beta_v");
        Element F_v = (Element) ciphertext.get("F_v");

        Element W_v = F_v.powZn(Sk_R.invert()).getImmutable();
        Element h_v = hashToZr(W_v.toString());
        String m_v = xorStrings(lambda_v, hashToString(h_v));
        Element PK = hashToZr(Pk_v.toString());
        Element j_v = hashToZr(m_v + Hv.toString() + Pk_v.toString() + W_v.toString());
        Element verification = j_v.invert().mul(PK).add(h_v).getImmutable();

        if (verification.isEqual(F_v)) {
            System.out.println("Unsigncryption successful.");
            return m_v;
        } else {
            System.out.println("Unsigncryption failed.");
            return "Invalid message.";
        }
    }

    private static Element hashToZr(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            return pairing.getZr().newElementFromHash(hash, 0, hash.length).getImmutable();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Hash function not found.");
        }
    }

    private static String xorStrings(String str1, String str2) {
        char[] result = new char[str1.length()];
        for (int i = 0; i < str1.length(); i++) {
            result[i] = (char) (str1.charAt(i) ^ str2.charAt(i % str2.length()));
        }
        return new String(result);
    }

    private static String hashToString(Element input) {
        try {
            return new String(input.toBytes());
        } catch (Exception e) {
            throw new RuntimeException("Error converting element to string.");
        }
    }

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            int j = i + 1;
            System.out.println("第" + j + "次执行:");
            long start = System.currentTimeMillis();

            setup();

            long end = System.currentTimeMillis();
            System.out.print("setup运行时间为");
            System.out.println(end - start);
            start = System.currentTimeMillis();

            String IDv = "Vehicle1";
            Map<String, Element> partialKeys = generatePartialPrivateKey(IDv);
            Map<String, Element> keys = generateKeys(partialKeys);
            end = System.currentTimeMillis();
            System.out.print("KeyGen运行时间为");
            System.out.println(end - start);

            //  partialKeys.put("mu_v", mu_v);
            //        partialKeys.put("Hv", Hv);
            //        keys.put("Sk_v", Sk_v);
            //        keys.put("X_v", X_v);
            //        keys.put("Y_v", Y_v);
            Integer totalBits = 0;
            totalBits += partialKeys.get("mu_v").toBytes().length;
            totalBits += partialKeys.get("Hv").toBytes().length;
            totalBits += keys.get("Sk_v").toBytes().length;
            totalBits += keys.get("X_v").toBytes().length;
            totalBits += keys.get("Y_v").toBytes().length;
            System.out.println("密钥长度为" + totalBits / 8 + "B");

            Element Sk_v = keys.get("Sk_v");
            Element Pk_v = keys.get("X_v");
            Element Hv = partialKeys.get("Hv");

            Element Pk_R = pairing.getG1().newRandomElement().getImmutable();
            Element Sk_R = pairing.getZr().newRandomElement().getImmutable();
            long start1 = System.currentTimeMillis();
            Map<String, Element> offlineCiphertext = offlineSigncrypt(Pk_R, Sk_v);
            String message = "Hello, secure world!";

            Map<String, Object> ciphertext = onlineSigncrypt(message, offlineCiphertext, Sk_v, Pk_v, Hv);

            long end1 = System.currentTimeMillis();
            System.out.print("SignCryption运行时间为");
            System.out.println(end1 - start1);
            start = System.currentTimeMillis();
            String recoveredMessage = unsigncrypt(ciphertext, Sk_R, Pk_v, Hv);
            end = System.currentTimeMillis();
            System.out.print("Decrypt运行时间为");
            System.out.println(end - start);
            System.out.println("Recovered Message: " + recoveredMessage);
        }
    }
}

