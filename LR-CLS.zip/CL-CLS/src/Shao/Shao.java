package Shao;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class Shao {
    private static Pairing pairing;
    private static Element P, W, Ppub, s;

    public static void setup() {
        // Initialize pairing
        pairing = PairingFactory.getPairing("a.properties");
        P = pairing.getG1().newRandomElement().getImmutable();
        W = pairing.getG1().newRandomElement().getImmutable();
        s = pairing.getZr().newRandomElement().getImmutable();
        Ppub = P.powZn(s).getImmutable();
        System.out.println("Setup complete.");
    }

    public static Map<String, Element> regAIDPSK(String vehicleId) throws NoSuchAlgorithmException {
        Map<String, Element> results = new HashMap<>();

        // Generate AIDV
        Element lambda = pairing.getZr().newRandomElement();
        Element AIDV1 = W.powZn(lambda).getImmutable();

        // Calculate P_IDV and AIDV
        Element PIDV = AIDV1.add(hashToG1(vehicleId).mul(Ppub)).getImmutable();
        Element AIDV = hashToZr(PIDV.toString()).getImmutable();

        // Calculate partial secret key
        Element PSKV = s.mul(AIDV).getImmutable();

        // Store results
        results.put("AIDV", AIDV);
        results.put("PSKV", PSKV);
        return results;
    }

    public static Map<String, Element> spkGen(Element PSKV) {
        Map<String, Element> results = new HashMap<>();

        // Generate SKV and PKV
        Element fi = pairing.getZr().newRandomElement();
        Element SKV = PSKV.mul(fi).getImmutable();
        Element PKV =  P.powZn(SKV).getImmutable();

        results.put("SKV", SKV);
        results.put("PKV", PKV);
        return results;
    }

    public static String[] signcrypt(String message, Element SKV, Element PKVj, Element AIDVi, Element AIDVj) {
        Element mu = pairing.getZr().newRandomElement().getImmutable();
        Element Ri = P.powZn(mu).getImmutable();

        // Compute h1
        String h1Input = AIDVi.toString() + AIDVj.toString() + message;
        Element h1 = hashToZr(h1Input);

        // Compute alpha
        Element alpha = pairing.pairing(P, P.powZn(SKV.add(h1))).getImmutable();

        // Compute beta
        Element PKVjMu = PKVj.powZn(mu).getImmutable();
        String beta = xorStrings(hashToString(PKVjMu), message);

        // Create message-signcryption tuple
        String[] sigma = new String[4];
        sigma[0] = Ri.toString();
        sigma[1] = alpha.toString();
        sigma[2] = beta;
        sigma[3] = String.valueOf(System.currentTimeMillis());

        Integer totalBits = 0;
        for (int i =0;i<4;i++){
            totalBits +=sigma[i].getBytes().length;
        }
        System.out.println("密文长度为" + totalBits / 8 + "B");
        return sigma;
    }

    public static String unsigncrypt(String[] sigma, Element SKVj, Element PKVi, Element AIDVi, Element AIDVj) {
        long currentTime = System.currentTimeMillis();
        long timestamp = Long.parseLong(sigma[3]);

        // Check timestamp validity
        if (currentTime - timestamp > 10000) { // 10 seconds
            return "Message rejected due to timestamp expiration.";
        }

        // Recover Ri and alpha
        Element Ri = pairing.getG1().newElementFromBytes(sigma[0].getBytes());
        Element alpha = pairing.getGT().newElementFromBytes(sigma[1].getBytes());

        // Recover beta and compute PKVj^Ri
        String beta = sigma[2];
        Element PKVjRi = pairing.pairing(Ri, P.powZn(SKVj)).getImmutable();
        String decryptedMessage = xorStrings(hashToString(PKVjRi), beta);

        // Verify authenticity
        String h1Input = AIDVi.toString() + AIDVj.toString() + decryptedMessage;
        Element h1 = hashToZr(h1Input);
        Element Z = PKVi.powZn(h1);
        Element expectedAlpha = pairing.pairing(P, Z).getImmutable();

        return decryptedMessage;
    }

    private static Element hashToG1(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            return pairing.getG1().newElementFromHash(hash, 0, hash.length).getImmutable();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Hash function not found.");
        }
    }


    private static Element hashToZr(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            return pairing.getZr().newElementFromHash(hash, 0, hash.length).getImmutable();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Hash function not found.");
        }
    }

    private static String hashToString(Element input) {
        try {
            return new String(input.toBytes());
        } catch (Exception e) {
            throw new RuntimeException("Error converting element to string.");
        }
    }
    private static String xorStrings(String str1, String str2) {
        int length = Math.min(str1.length(),str2.length());
        char[] result = new char[length];
        for (int i = 0; i < length; i++) {
            result[i] = (char) (str1.charAt(i) ^ str2.charAt(i));
        }
        return new String(result);
    }


    public static void main(String[] args) throws Exception {

        for (int i = 0; i < 10; i++) {
            // 初始化系统
            int j = i + 1;
            System.out.println("第" + j + "次执行:");
            long start = System.currentTimeMillis();
            setup();
            long end = System.currentTimeMillis();
            System.out.print("setup运行时间为");
            System.out.println(end - start);

            start = System.currentTimeMillis();
            // Vehicle registration
            String vehicleId = "Vehicle1";
            Map<String, Element> regResults = regAIDPSK(vehicleId);

            // SPK generation
            Element PSKV = regResults.get("PSKV");
            Element AIDV = regResults.get("AIDV");
            Map<String, Element> spkResults = spkGen(PSKV);

            Element SKV = spkResults.get("SKV");
            Element PKV = spkResults.get("PKV");
            end = System.currentTimeMillis();
            System.out.print("KeyGen运行时间为");
            System.out.println(end - start);


            Integer totalBits = 0;
            totalBits +=SKV.toBytes().length;
            totalBits += PKV.toBytes().length;
            totalBits +=PSKV.toBytes().length;
            totalBits += AIDV.toBytes().length;
            System.out.println("密钥长度为" + totalBits / 8 + "B");

            // Signcryption
            start = System.currentTimeMillis();
            String message = "Hello, VANET!";
            Element AIDVi = regResults.get("AIDV");
            Element AIDVj = pairing.getG1().newRandomElement().getImmutable();
            Element PKVj = pairing.getG1().newRandomElement().getImmutable();

            String[] sigma = signcrypt(message, SKV, PKVj, AIDVi, AIDVj);
            String.join(", ", sigma);
            end = System.currentTimeMillis();
            System.out.print("SignCryption运行时间为");
            System.out.println(end - start);
            // Unsigncryption
            start = System.currentTimeMillis();
            Element SKVj = pairing.getZr().newRandomElement().getImmutable();
            String result = unsigncrypt(sigma, SKVj, PKV, AIDVi, AIDVj);
            end = System.currentTimeMillis();
            System.out.print("Decrypt运行时间为");
            System.out.println(end - start);
        }
    }
}
