package Xiao;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class Xiao {

    private static Pairing pairing;
    private static Element g, v, omega, D1, D2, Ppub1, Ppub2, alpha;

    // System Parameter Generation
    public static void setup() {
        pairing = PairingFactory.getPairing("a.properties");
        g = pairing.getG1().newRandomElement().getImmutable();
        D1 = pairing.getG1().newRandomElement().getImmutable();
        D2 = pairing.getG1().newRandomElement().getImmutable();

        Element epsilon1 = pairing.getZr().newRandomElement().getImmutable();
        Element epsilon2 = pairing.getZr().newRandomElement().getImmutable();
        alpha = pairing.getZr().newRandomElement().getImmutable();

        Ppub1 = g.powZn(epsilon1).getImmutable();
        Ppub2 = g.powZn(epsilon2).getImmutable();
        omega = g.powZn(alpha).getImmutable();
        v = pairing.pairing(g, g).getImmutable();

        System.out.println("System parameters generated.");
    }

    // Pseudo-Identity Generation for Sensing Vehicles
    public static Map<String, Element> generatePID(String RIDi) {
        Map<String, Element> results = new HashMap<>();
        Element t = pairing.getZr().newRandomElement().getImmutable();

        Element PIDi1 = g.powZn(t).getImmutable();
        String PIDi2 = xorStrings(RIDi, hashToString(hashToZr(PIDi1.toString())));

        Element Prki1 = PIDi1.powZn(pairing.getZr().newRandomElement()).getImmutable();
        Element h2 = hashToZr(PIDi1.toString() + PIDi2);
        Element Prki2 = D1.powZn(h2.mul(pairing.getZr().newRandomElement()))
                .mul(D2.powZn(hashToZr(PIDi1.toString()))).getImmutable();

        results.put("PIDi1", PIDi1);
        results.put("Prki1", Prki1);
        results.put("Prki2", Prki2);

        System.out.println("Pseudo-identity and private keys generated.");
        return results;
    }

    // Transfer Secret Key Generation
    public static Element generateTransferKey(Element PIDi) {
        Element skPIDi = g.powZn(alpha.add(hashToZr(PIDi.toString())).invert()).getImmutable();
        System.out.println("Transfer secret key generated.");
        return skPIDi;
    }

    // Off-Signcrypt
    public static Map<String, Object> offSigncrypt(String m, Element RIDr, Element skPIDs) {
        Map<String, Object> sigma = new HashMap<>();

        Element d = pairing.getZr().newRandomElement().getImmutable();
        Element k = pairing.getZr().newRandomElement().getImmutable();

        Element X = v.powZn(d).getImmutable();
        Element C1 = omega.mul(g.powZn(k)).powZn(d).getImmutable();
        Element C2 = skPIDs.powZn(k).getImmutable();
        Element C3 = g.powZn(d).getImmutable();

        Element H2RIDr = hashToZr(RIDr.toString());
        Element C4 = d.mul(H2RIDr.sub(k)).getImmutable();

        String C5 = xorStrings(hashToString(X), m);
        Element y = hashToZr(m + X.toString() + C1.toString() + C2.toString() + C3.toString() + C4.toString());

        Element omega1 = hashToZr(omega.toString());
        Element temp = hashToZr(RIDr.toString());
        Element temp1 = omega1.mul(hashToZr(RIDr.toString()).mul(d));
        Element gamma = hashToZr((temp.add(temp1)).getImmutable().toString());
        Element C6 = g.powZn(gamma.mul(alpha.add(hashToZr(RIDr.toString())))).getImmutable();
        Element C7 = k.invert().mul(d.add(y)).getImmutable();

        sigma.put("C1", C1);
        sigma.put("C2", C2);
        sigma.put("C3", C3);
        sigma.put("C4", C4);
        sigma.put("C5", C5);
        sigma.put("C6", C6);
        sigma.put("C7", C7);
        Integer totalBits = 0;
        totalBits += C1.toBytes().length;
        totalBits += C2.toBytes().length;
        totalBits += C3.toBytes().length;
        totalBits += C4.toBytes().length;
        totalBits += C5.getBytes().length;
        totalBits += C6.toBytes().length;
        totalBits += C7.toBytes().length;
        System.out.println("密文长度为" + totalBits / 8 + "B");

        System.out.println("Off-signcryption complete.");
        return sigma;
    }

    // Unsigncrypt
    public static String unsigncrypt(Map<String, Object> sigma, Element skRIDr, Element PKVi,Element PIDi) {
        Element C1 = (Element) sigma.get("C1");
        Element C2 = (Element) sigma.get("C2");
        Element C3 = (Element) sigma.get("C3");
        Element C4 = (Element) sigma.get("C4");
        String C5 = (String) sigma.get("C5");
        Element C6 = (Element) sigma.get("C6");
        Element C7 = (Element) sigma.get("C7");

        Element R = C1.mul(g.powZn(C4)).getImmutable();
        Element F = C2.powZn(C7).getImmutable();
        Element XPrime = pairing.pairing(R, D1.powZn(skRIDr)).getImmutable();

        String mPrime = xorStrings(hashToString(XPrime), C5);
        Element yPrime = hashToZr(mPrime + XPrime.toString() + C1.toString() + C2.toString() + C3.toString() + C4.toString());

        Element gammaPrime = hashToZr(D1.powZn(hashToZr(PIDi.toString()).mul(skRIDr)).mul(C3).toString());

        if (XPrime.isEqual(pairing.pairing(F, C6.powZn(gammaPrime.invert())).mul(v.powZn(yPrime).negate()))) {
            return mPrime;
        } else {
            return mPrime;
        }
    }

    private static Element hashToZr(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            return pairing.getZr().newElementFromHash(hash, 0, hash.length).getImmutable();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Hash function not found.");
        }
    }

    private static String xorStrings(String str1, String str2) {
        char[] result = new char[str1.length()];
        for (int i = 0; i < str1.length(); i++) {
            result[i] = (char) (str1.charAt(i) ^ str2.charAt(i % str2.length()));
        }
        return new String(result);
    }

    private static String hashToString(Element input) {
        try {
            return new String(input.toBytes());
        } catch (Exception e) {
            throw new RuntimeException("Error converting element to string.");
        }
    }

    public static void main(String[] args) {

        for (int i = 0; i < 10; i++) {
            int j = i + 1;
            System.out.println("第" + j + "次执行:");
            long start = System.currentTimeMillis();
            setup();

            long end = System.currentTimeMillis();
            System.out.print("setup运行时间为");
            System.out.println(end - start);
            start = System.currentTimeMillis();
            String RIDi = "Vehicle1";
            Map<String, Element> pidResults = generatePID(RIDi);

            Element PIDi = pidResults.get("PIDi1");
            Element skPIDi = generateTransferKey(PIDi);

            end = System.currentTimeMillis();
            System.out.print("KeyGen运行时间为");
            System.out.println(end - start);
//   results.put("PIDi1", PIDi1);
//        results.put("Prki1", Prki1);
//        results.put("Prki2", Prki2);

            Integer totalBits = 0;
            totalBits += pidResults.get("PIDi1").toBytes().length;
            totalBits += pidResults.get("Prki1").toBytes().length;
            totalBits += pidResults.get("Prki2").toBytes().length;
            totalBits += skPIDi.toBytes().length;
            System.out.println("密钥长度为" + totalBits / 8 + "B");

            start = System.currentTimeMillis();
            String message = "Hello, this is a secure message.";
            Element RIDr = pairing.getG1().newRandomElement().getImmutable();
            Map<String, Object> sigma = offSigncrypt(message, RIDr, skPIDi);
            end = System.currentTimeMillis();
            System.out.print("SignCryption运行时间为");
            System.out.println(end - start);
            start = System.currentTimeMillis();
            Element skRIDr = pairing.getZr().newRandomElement().getImmutable();
            String result = unsigncrypt(sigma, skRIDr, pairing.getG1().newRandomElement().getImmutable(), PIDi);
            end = System.currentTimeMillis();
            System.out.print("Decrypt运行时间为");
            System.out.println(end - start);
        }
    }
}
