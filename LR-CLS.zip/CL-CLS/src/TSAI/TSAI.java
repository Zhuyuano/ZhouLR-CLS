package TSAI;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class TSAI {

    private static Pairing pairing;
    private static Element g, SPK, T, K, U, V;
    private static Element SMK_A, SMK_B;

    // Setup
    public static void setup() {
        pairing = PairingFactory.getPairing("a.properties");
        g = pairing.getG1().newRandomElement().getImmutable();

        Element s = pairing.getZr().newRandomElement().getImmutable();
        Element a = pairing.getZr().newRandomElement().getImmutable();

        SMK_A = g.powZn(a).getImmutable();
        SMK_B = g.powZn(a.negate()).mul(g.powZn(s)).getImmutable();

        SPK = pairing.pairing(g.powZn(s), g).getImmutable();

        Element t = pairing.getZr().newRandomElement().getImmutable();
        Element k = pairing.getZr().newRandomElement().getImmutable();
        Element u = pairing.getZr().newRandomElement().getImmutable();
        Element v = pairing.getZr().newRandomElement().getImmutable();

        T = g.powZn(t).getImmutable();
        K = g.powZn(k).getImmutable();
        U = g.powZn(u).getImmutable();
        V = g.powZn(v).getImmutable();



        System.out.println("Setup complete. Public parameters and master key generated.");
    }

    // Entity Partial Keys Generation
    public static Map<String, Element> generatePartialKeys(String ID) {
        Map<String, Element> keys = new HashMap<>();

        Element b = pairing.getZr().newRandomElement().getImmutable();
        SMK_A = SMK_A.mul(g.powZn(b)).getImmutable();
        SMK_B = SMK_B.mul(g.powZn(b.negate())).getImmutable();

        Element r = pairing.getZr().newRandomElement().getImmutable();
        Element KPK_ID = g.powZn(r).getImmutable();

        Element TK_ID = SMK_A.mul(T.mul(K.powZn(hashToZr(ID))).powZn(r)).getImmutable();
        Element KSK_ID = SMK_B.mul(TK_ID).getImmutable();

        keys.put("KPK_ID", KPK_ID);
        keys.put("KSK_ID", KSK_ID);



        return keys;
    }

    // Entity Keys Generation
    public static Map<String, Element> generateEntityKeys() {
        Map<String, Element> entityKeys = new HashMap<>();

        Element e = pairing.getZr().newRandomElement().getImmutable();
        Element ESK_ID = g.powZn(e).getImmutable();
        Element EPK_ID = pairing.pairing(ESK_ID, g).getImmutable();

        entityKeys.put("ESK_ID", ESK_ID);
        entityKeys.put("EPK_ID", EPK_ID);

        System.out.println("Entity keys generated.");
        return entityKeys;
    }

    // Signcryption
    public static Map<String, Object> signcrypt(String message, Element KSK_ID, Element ESK_ID, Element KPK_ID_r, Element EPK_ID_r) {
        Map<String, Object> ciphertext = new HashMap<>();

        Element h = pairing.getZr().newRandomElement().getImmutable();
        KSK_ID = KSK_ID.mul(g.powZn(h)).getImmutable();
        ESK_ID = ESK_ID.mul(g.powZn(h)).getImmutable();

        Element alpha = pairing.getZr().newRandomElement().getImmutable();
        Element CT_1 = g.powZn(alpha).getImmutable();
        Element SK_1 = EPK_ID_r.powZn(alpha).getImmutable();
        Element SK_2 = SPK.mul(pairing.pairing(KPK_ID_r, T.mul(K.powZn(hashToZr("ID_r")))).powZn(alpha)).getImmutable();

        Element SK = SK_1.mul(SK_2).getImmutable();
        String CT_2 = xorStrings(hashToString(SK), message);

        Element f = hashToZr(message + CT_1.toString() + CT_2);
        Element TS = KSK_ID.mul(ESK_ID).mul(U.mul(V.powZn(f)).powZn(alpha)).getImmutable();
        Element CT_0 = KSK_ID.mul(ESK_ID).mul(TS).getImmutable();

        ciphertext.put("CT_0", CT_0);
        ciphertext.put("CT_1", CT_1);
        ciphertext.put("CT_2", CT_2);

        Integer totalBits = 0;
        totalBits+=CT_0.toBytes().length;
        totalBits+=CT_1.toBytes().length;
        totalBits+=CT_2.getBytes().length;
        System.out.println("密文长度为"+totalBits/8+"B");

        System.out.println("Signcryption completed.");
        return ciphertext;
    }

    // Unsigncryption
    public static String unsigncrypt(Map<String, Object> ciphertext, Element KSK_ID_r, Element ESK_ID_r, Element KPK_ID_s, Element EPK_ID_s) {
        Element CT_1 = (Element) ciphertext.get("CT_1");
        String CT_2 = (String) ciphertext.get("CT_2");

        Element SK_1 = EPK_ID_s.powZn(hashToZr("alpha")).getImmutable();
        Element SK_2 = SPK.mul(pairing.pairing(KPK_ID_s, T.mul(K.powZn(hashToZr("ID_s")))).powZn(hashToZr("alpha"))).getImmutable();

        Element SK = SK_1.mul(SK_2).getImmutable();
        String message = xorStrings(hashToString(SK), CT_2);

        System.out.println("Unsigncryption completed. Message: " + message);
        return message;
    }

    private static Element hashToZr(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            return pairing.getZr().newElementFromHash(hash, 0, hash.length).getImmutable();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Hash function not found.");
        }
    }

    private static String xorStrings(String str1, String str2) {
        char[] result = new char[str1.length()];
        for (int i = 0; i < str1.length(); i++) {
            result[i] = (char) (str1.charAt(i) ^ str2.charAt(i % str2.length()));
        }
        return new String(result);
    }

    private static String hashToString(Element input) {
        return new String(input.toBytes());
    }

    public static void main(String[] args) {

        for (int i = 0; i < 10; i++) {
            int j = i + 1;
            System.out.println("第" + j + "次执行:");
            long start = System.currentTimeMillis();
            setup();
            long end = System.currentTimeMillis();
            System.out.print("setup运行时间为");
            System.out.println(end - start);
            String ID = "Entity1";
            start = System.currentTimeMillis();
            Map<String, Element> partialKeys = generatePartialKeys(ID);
            Map<String, Element> entityKeys = generateEntityKeys();
            end = System.currentTimeMillis();
            System.out.print("KeyGen运行时间为");
            System.out.println(end - start);

            Integer totalBits = 0;
            totalBits += partialKeys.get("KSK_ID").toBytes().length;
            totalBits += partialKeys.get("KPK_ID").toBytes().length;
            totalBits += entityKeys.get("EPK_ID").toBytes().length;
            totalBits += entityKeys.get("ESK_ID").toBytes().length;
            System.out.println("密钥长度为" + totalBits / 8 + "B");

            Element KSK_ID = partialKeys.get("KSK_ID");
            Element ESK_ID = entityKeys.get("ESK_ID");
            start = System.currentTimeMillis();
            String message = "This is a secure message.";
            Element KPK_ID_r = pairing.getG1().newRandomElement().getImmutable();
            Element EPK_ID_r = pairing.getGT().newRandomElement().getImmutable();

            Map<String, Object> ciphertext = signcrypt(message, KSK_ID, ESK_ID, KPK_ID_r, EPK_ID_r);
            end = System.currentTimeMillis();
            System.out.print("SignCryption运行时间为");
            System.out.println(end - start);
            start = System.currentTimeMillis();
            unsigncrypt(ciphertext, KSK_ID, ESK_ID, KPK_ID_r, EPK_ID_r);
            end = System.currentTimeMillis();
            System.out.print("Decrypt运行时间为");
            System.out.println(end - start);
        }
    }
}

