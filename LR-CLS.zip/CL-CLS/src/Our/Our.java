package Our;


import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class Our {

    private static Pairing pairing;
    private static Element P;       // 生成元
    private static Element Ppub;    // 主公钥
    private static Element s;       // 主私钥

    // 哈希函数，模拟为SHA-256
    public static Element hashToZr(String input) throws NoSuchAlgorithmException {
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        byte[] hash = sha256.digest(input.getBytes());
        return pairing.getZr().newElementFromHash(hash, 0, hash.length).getImmutable();
    }

    public static void main(String[] args) throws Exception {

        for(int i= 0;i<10;i++){
            // 初始化系统
            int j =i+1;
            System.out.println("第"+j+"次执行:");
            long start = System.currentTimeMillis();
            setup();
            long end = System.currentTimeMillis();
            System.out.print("setup运行时间为");
            System.out.println(end - start);

            // 示例用户
            String idAlice = "Alice";
            String idBob = "Bob";
            String message = "Hello, Bob!";
            start = System.currentTimeMillis();
            // 用户密钥生成
            Map<String, Element> aliceKeys = keyGen(idAlice);
            Map<String, Element> bobKeys = keyGen(idBob);
            end = System.currentTimeMillis();
            System.out.print("KeyGen运行时间为");
            System.out.println(end - start);
            // 签密
            start = System.currentTimeMillis();
            Map<String, Element> signcryptedMessage = signcryption(idAlice, aliceKeys, idBob, bobKeys, message);
            end = System.currentTimeMillis();
            System.out.print("SignCryption运行时间为");
            System.out.println(end - start);
            // 验证
            start = System.currentTimeMillis();
            boolean isVerified = verify(idAlice, aliceKeys, idBob, bobKeys, signcryptedMessage);
            end = System.currentTimeMillis();
            System.out.print("Verify运行时间为");
            System.out.println(end - start);
            // 解密
            start = System.currentTimeMillis();
            String decryptedMessage = unsigncryption(idAlice, idBob, bobKeys, signcryptedMessage);
            end = System.currentTimeMillis();
            System.out.print("Decrypt运行时间为");
            System.out.println(end - start);
        }

    }

    /**
     * 系统初始化
     */
    public static void setup() {
        // 加载配对参数
        pairing = PairingFactory.getPairing("E:/java program/CL-CLS/a.properties");
        // 生成生成元 P 和主私钥 s
        P = pairing.getG1().newRandomElement().getImmutable();
        s = pairing.getZr().newRandomElement().getImmutable();
        // 计算主公钥 Ppub = s * P
        Ppub = P.powZn(s).getImmutable();

    }

    /**
     * 密钥生成
     * @param id 用户标识
     * @return 公钥 (X, Y) 和私钥 (x, y)
     */
    public static Map<String, Element> keyGen(String id) throws NoSuchAlgorithmException {
        Map<String, Element> keys = new HashMap<>();

        // 生成私钥 x
        Element x = pairing.getZr().newRandomElement().getImmutable();
        Element X = P.powZn(x).getImmutable(); // 公钥 X = x * P

        // KGC生成部分私钥 y
        Element u = pairing.getZr().newRandomElement().getImmutable();
        Element Y = P.powZn(u).getImmutable();
        Element H1 = hashToZr(id + X.toString() + Y.toString() + Ppub.toString());
        Element y = u.add(H1.mulZn(s)).getImmutable(); // y = u + H1 * s

        // 保存公钥和私钥
        keys.put("x", x); // 私钥 x
        keys.put("y", y); // 私钥 y
        keys.put("X", X); // 公钥 X
        keys.put("Y", Y); // 公钥 Y

        Integer totalBits = 0;
        totalBits +=X.toBytes().length;
        totalBits += Y.toBytes().length;
        totalBits +=x.toBytes().length;
        totalBits += y.toBytes().length;
        System.out.println("密钥长度为" + totalBits / 8 + "B");

        return keys;
    }

    /**
     * 签密
     */
    public static Map<String, Element> signcryption(String idSender, Map<String, Element> senderKeys,
                                                    String idReceiver, Map<String, Element> receiverKeys,
                                                    String message) throws NoSuchAlgorithmException {
        Map<String, Element> result = new HashMap<>();

        // 随机生成会话密钥
        Element k = pairing.getZr().newRandomElement().getImmutable();
        Element t = pairing.getZr().newRandomElement().getImmutable();

        // 计算 K 和 T
        Element K = P.powZn(k).getImmutable();
        Element T = P.powZn(t).getImmutable();

        // 计算接收方的 Q 值
        Element RX = receiverKeys.get("X");
        Element RY = receiverKeys.get("Y");
        Element H1 = hashToZr(idReceiver + RX.toString() + RY.toString() + Ppub.toString());
        Element Q1 = RX.add(RY.add(Ppub.powZn(H1))).powZn(k);
        Element Q2 = RY.powZn(t);
        Element Q = Q1.add(Q2);

        // 加密消息
        byte[] messageBytes = message.getBytes();
        byte[] hashQ = hashToZr(idReceiver + Q.toString()).toBytes();
        byte[] cipherText = new byte[messageBytes.length];
        for (int i = 0; i < messageBytes.length; i++) {
            cipherText[i] = (byte) (messageBytes[i] ^ hashQ[i % hashQ.length]);
        }
        Element C = pairing.getZr().newElementFromHash(cipherText, 0, cipherText.length);

        // 生成签名
        Element SX = senderKeys.get("X");
        Element SY = senderKeys.get("Y");
        byte[] hashSign = hashToZr(idSender + idReceiver + SX.toString() + SY.toString() +
                RX.toString() + RY.toString() + C.toString() + K.toString() + T.toString()).toBytes();
        Element H3 = pairing.getZr().newElementFromHash(hashSign, 0, hashSign.length);
        Element H4 = pairing.getZr().newElementFromHash(hashSign, 0, hashSign.length);
        Element H5 = pairing.getZr().newElementFromHash(hashSign, 0, hashSign.length);
        Element Sx = senderKeys.get("x");
        Element Sy = senderKeys.get("y");
        Element sign = H3.mulZn(t).add(H4.mulZn(Sx)).add(H5.mulZn(Sy)).getImmutable();

        // 保存结果
        result.put("K", K);
        result.put("T", T);
        result.put("C", C);
        result.put("sign", sign);
        Integer totalBits = 0;
        totalBits += K.toBytes().length;
        totalBits += C.toBytes().length;
        totalBits += T.toBytes().length;
        totalBits += sign.toBytes().length;
        System.out.println("密文长度为" + totalBits / 8 + "B");
        return result;
    }

    /**
     * 验证
     */
    public static boolean verify(String idSender, Map<String, Element> senderKeys,
                                 String idReceiver, Map<String, Element> receiverKeys,
                                 Map<String, Element> signcryptedMessage) throws NoSuchAlgorithmException {
        Element K = signcryptedMessage.get("K");
        Element T = signcryptedMessage.get("T");
        Element C = signcryptedMessage.get("C");
        Element sign = signcryptedMessage.get("sign");

        Element SX = senderKeys.get("X");
        Element SY = senderKeys.get("Y");
        Element RX = receiverKeys.get("X");
        Element RY = receiverKeys.get("Y");

        // 计算 H3, H4, H5
        byte[] hashSign = hashToZr(idSender + idReceiver + SX.toString() + SY.toString() +
                RX.toString() + RY.toString() + C.toString() + K.toString() + T.toString()).toBytes();
        Element H3 = pairing.getZr().newElementFromHash(hashSign, 0, hashSign.length);
        Element H4 = pairing.getZr().newElementFromHash(hashSign, 0, hashSign.length);
        Element H5 = pairing.getZr().newElementFromHash(hashSign, 0, hashSign.length);

        // 验证签名
        Element left = P.powZn(sign);
        Element right = T.powZn(H3).add(SX.powZn(H4)).add(SY.add(Ppub.powZn(H5)));
        boolean isValid = left.isEqual(right);
        return isValid;
    }

    /**
     * 解密
     */
    public static String unsigncryption(String idSender, String idReceiver, Map<String, Element> receiverKeys,
                                        Map<String, Element> signcryptedMessage) throws NoSuchAlgorithmException {
        Element K = signcryptedMessage.get("K");
        Element T = signcryptedMessage.get("T");
        Element C = signcryptedMessage.get("C");

        Element Rx = receiverKeys.get("x");
        Element Ry = receiverKeys.get("y");

        // 计算 Q
        Element Q = K.powZn(Rx.add(Ry)).add(T.powZn(Ry));

        // 解密消息
        byte[] cipherText = C.toBytes();
        byte[] hashQ = hashToZr(idSender + Q.toString()).toBytes();
        byte[] messageBytes = new byte[cipherText.length];
        for (int i = 0; i < cipherText.length; i++) {
            messageBytes[i] = (byte) (cipherText[i] ^ hashQ[i % hashQ.length]);
        }
        return new String(messageBytes);
    }
}
